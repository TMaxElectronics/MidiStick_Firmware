#ifndef DUTYCOMP
#define DUTYCOMP

#include <stdint.h>

void COMP_compress();
inline int32_t COMP_getGain();

#endif