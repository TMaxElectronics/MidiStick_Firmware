void APP_DeviceCustomHIDInitialize();
void APP_DeviceCustomHIDStart();
void usbTasks();

